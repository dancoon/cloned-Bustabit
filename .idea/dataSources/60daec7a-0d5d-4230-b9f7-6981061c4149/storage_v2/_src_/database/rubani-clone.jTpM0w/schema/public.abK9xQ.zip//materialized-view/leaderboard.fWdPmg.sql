create materialized view leaderboard as
SELECT id                                       AS user_id,
       username,
       gross_profit,
       net_profit,
       games_played,
       rank() OVER (ORDER BY gross_profit DESC) AS rank
FROM users;

alter materialized view leaderboard owner to "rubani-clone_owner";

create unique index leaderboard_user_id_idx
    on leaderboard (user_id);

create index leaderboard_username_idx
    on leaderboard (lower(username));

create index leaderboard_gross_profit_idx
    on leaderboard (gross_profit);

create index leaderboard_net_profit_idx
    on leaderboard (net_profit);

