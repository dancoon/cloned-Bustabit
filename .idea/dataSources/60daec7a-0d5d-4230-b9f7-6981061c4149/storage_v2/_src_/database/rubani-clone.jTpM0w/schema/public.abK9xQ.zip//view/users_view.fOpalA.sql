create view users_view
            (id, created, username, email, password, mfa_secret, balance_satoshis, last_giveaway, userclass) as
SELECT id,
       created,
       username,
       email,
       password,
       mfa_secret,
       balance_satoshis,
       (SELECT max(giveaways.created) AS max
        FROM giveaways
        WHERE giveaways.user_id = u.id) AS last_giveaway,
       userclass
FROM users u;

alter table users_view
    owner to "rubani-clone_owner";

